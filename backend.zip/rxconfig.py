import reflex as rx

config = rx.Config(
    app_name="pythontfg",
    api_url="https://97fcd1cf-0812-4f12-b2d7-21dbde0abb73.fly.dev",
)