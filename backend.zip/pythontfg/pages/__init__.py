from .about import about
from .index import index
#from .login import login
from .profile import profile
from .settings import settings

__all__ = ["about", "index", "profile", "chat", "settings", "contactos", "login", "registrarse"]
