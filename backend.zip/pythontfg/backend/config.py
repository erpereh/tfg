
""" APIs IA """
KEY_OPEN_ROUTER = "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"


""" BASE_URL IA """
BASE_URL_OPEN_ROUTER="https://openrouter.ai/api/v1"


""" SUPABASE """
SUPABASE_URL = "https://kpwbkzdjqgginzpfcpsd.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imtwd2JremRqcWdnaW56cGZjcHNkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDQ2NTYxMzUsImV4cCI6MjA2MDIzMjEzNX0.pBbx1E1vxNa1FunK0rXau--7SoA9934S7ISWixm-i2M"